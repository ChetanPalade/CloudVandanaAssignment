let subgroupElement = document.getElementById("form-group");
let submitInTextElement = document.getElementById("submit");
function Submitbtn() {
  let inputValue = form-group.value;
  let verifyText = "Thank YOu For Your Survey";
  submitInTextElement.textContent = verifyText;
}
