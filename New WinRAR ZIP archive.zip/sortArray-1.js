//javascript
array1 = [1,2,3,4,5]; 
array2 = [54,23,12,97,100]; 
  
function arrSort(arr) { 
    arr.sort((a,b)=>a-b); 
    arr.reverse(); 
    return arr; 
} 
  
console.log(arrSort(array1)); 
console.log(arrSort(array2));
