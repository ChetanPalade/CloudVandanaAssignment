package pkg.TestAccount;
import java.util.ArrayList;
import java.util.Collections;

public class TestJavaAssignments {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		        // Create an ArrayList with the values from 1 to 7......
		        ArrayList<Integer> arrayList = new ArrayList<>();
		        arrayList.add(1);
		        arrayList.add(2);
		        arrayList.add(3);
		        arrayList.add(4);
		        arrayList.add(5);
		        arrayList.add(6);
		        arrayList.add(7);

		        // Shuffle the ArrayList 
		        Collections.shuffle(arrayList);

		        // Convert the shuffled ArrayList back to an array
		        Integer[] shuffledArray = new Integer[arrayList.size()];
		        arrayList.toArray(shuffledArray);

		        // Print the shuffled array
		        for (int i = 0; i < shuffledArray.length; i++) {
		            System.out.print(shuffledArray[i] + " ");
		        }
		    }
		}