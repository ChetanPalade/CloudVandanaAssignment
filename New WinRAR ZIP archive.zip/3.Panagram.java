package pkg.TestAccount;



import java.util.Scanner;
public class TestJavaAssignments {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter a sentence: ");
	        String input = scanner.nextLine().toLowerCase(); // Convert to lowercase for case insensitivity
	        scanner.close();

	        boolean isPangram = checkIfPangram(input);

	        if (isPangram) {
	            System.out.println("The input is a pangram.");
	        } else {
	            System.out.println("The input is not a pangram.");
	        }
	    }

	    public static boolean checkIfPangram(String input) {
	        boolean[] alphabetCheck = new boolean[26]; // Initialize an array to check if each letter is present

	        for (char c : input.toCharArray()) {
	            if (Character.isLetter(c)) {
	                int index = c - 'a';
	                alphabetCheck[index] = true;
	            }
	        }

	        for (boolean letterPresent : alphabetCheck) {
	            if (!letterPresent) {
	                return false; // If any letter is missing, it's not a pangram
	            }
	        }

	        return true;
	    }
	}